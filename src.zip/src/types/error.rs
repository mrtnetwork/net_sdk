use std::fmt;

use rustls::Error as RustlsError;

// Your enum with optional inner error
#[derive(Debug, Clone)]
pub enum ResultStatus {
    OK,
    InvalidUrl,
    TlsError {
        source: RustlsError, // store original TLS error
    },
    NetError,
    TorNetError,
    InvalidServerName,
    InvalidGrpcMethodPath,
}
// Implement From so rustls::Error can be converted automatically
impl From<RustlsError> for ResultStatus {
    fn from(err: RustlsError) -> Self {
        ResultStatus::TlsError { source: err }
    }
}
impl fmt::Display for ResultStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?}", self)
    }
}

impl std::error::Error for ResultStatus {}
