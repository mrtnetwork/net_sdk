pub struct HttpResponse {
    pub status_code: u16,
    pub body: Vec<u8>,
}

pub struct HttpHeader {
    pub key: String,
    pub value: String,
}
pub struct HttpAuth {
    pub key: String,
    pub value: String,
}
pub struct HttpDigestAuth {
    pub key: String,
    pub value: String,
}

pub struct HttpConfig {
    pub headers: Vec<HttpHeader>,
    pub auth: Option<HttpAuth>,
    pub digest_auth: Option<HttpDigestAuth>,
}
