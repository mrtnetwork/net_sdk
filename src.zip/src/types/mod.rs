pub mod error;
pub mod response;
#[derive(Debug, Clone)]
pub struct AddressInfo {
    pub host: String,
    pub url: String,
    pub port: u16,
    pub is_tls: bool,
}
