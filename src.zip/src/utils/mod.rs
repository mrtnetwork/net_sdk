use rustls::pki_types::ServerName;
use url::Url;

use crate::types::{AddressInfo, error::ResultStatus};

pub struct Utils;

impl Utils {
    // This is now a "static" method on Utils
    pub fn parse_ws_url(url_str: &str) -> Result<AddressInfo, ResultStatus> {
        let url = Url::parse(url_str).map_err(|_| ResultStatus::InvalidUrl)?;
        let is_tls = match url.scheme() {
            "ws" => false,
            "wss" => true,
            _ => return Err(ResultStatus::InvalidUrl),
        };
        let host = url
            .host_str()
            .ok_or_else(|| ResultStatus::InvalidUrl)?
            .to_string();
        let port = url.port().unwrap_or_else(|| if is_tls { 443 } else { 80 });
        Ok(AddressInfo {
            host,
            port,
            is_tls,
            url: url_str.to_string(),
        })
    }

    pub fn get_server_name(host: &str) -> Result<ServerName<'static>, ResultStatus> {
        ServerName::try_from(host.to_owned()).map_err(|_| ResultStatus::InvalidServerName)
    }

    pub fn parse_tcp_url(url_str: &str) -> Result<AddressInfo, ResultStatus> {
        let url = Url::parse(url_str).map_err(|_| ResultStatus::InvalidUrl)?;
        let is_tls = match url.scheme() {
            "tcp" => false,
            "tls" | "tcp+tls" => true,
            _ => return Err(ResultStatus::InvalidUrl),
        };
        let port = url.port().unwrap_or_else(|| if is_tls { 443 } else { 80 });
        let host = url
            .host_str()
            .ok_or_else(|| ResultStatus::InvalidUrl)?
            .to_string();
        Ok(AddressInfo {
            host,
            port,
            is_tls,
            url: url_str.to_string(),
        })
    }

    pub fn parse_http_url(url_str: &str) -> Result<AddressInfo, ResultStatus> {
        let url = Url::parse(url_str).map_err(|_| ResultStatus::InvalidUrl)?;
        let is_tls = match url.scheme() {
            "http" => false,
            "https" => true,
            _ => return Err(ResultStatus::InvalidUrl),
        };
        let port = url.port().unwrap_or_else(|| if is_tls { 443 } else { 80 });
        let host = url
            .host_str()
            .ok_or_else(|| ResultStatus::InvalidUrl)?
            .to_string();
        Ok(AddressInfo {
            host,
            port,
            is_tls,
            url: url_str.to_string(),
        })
    }
}
