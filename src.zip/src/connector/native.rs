use arti_client::DataStream;
use once_cell::sync::Lazy;
use std::{
    collections::HashMap,
    sync::{Arc, Mutex},
};
use tokio::{net::TcpStream, runtime::Runtime};
use tokio_rustls::client::TlsStream;

use crate::{
    client::{
        IClient, IGrpcClient, IStreamClient, grpc::native::GrpcClient,
        raw::native::RawStreamClient, websocket::native::WsStreamClient,
    },
    utils::Utils,
};

static TRANSPORTERS: Lazy<Mutex<HashMap<u32, TransporterEntry>>> =
    Lazy::new(|| Mutex::new(HashMap::new()));
static RUNTIME: Lazy<Runtime> = Lazy::new(|| Runtime::new().unwrap());

static GLOBAL_TRANSPORTER: Lazy<Mutex<Option<DartTransporter>>> = Lazy::new(|| Mutex::new(None));
static mut NEXT_TRANSPORTER_ID: u32 = 1;
pub type DartCallbackC = extern "C" fn(response: u8);

pub struct DartTransporter {}

impl DartTransporter {
    pub fn new() -> Self {
        Self {}
    }
    pub fn tet(&self, cb: DartCallbackC) {
        // spawn async task on your static runtime
        RUNTIME.spawn(async move {
            let addr = Utils::parse_http_url("url_str").unwrap();
            let c = GrpcClient::<TlsStream<DataStream>>::connect(&addr)
                .await
                .unwrap();
            let c2 = GrpcClient::<TlsStream<TcpStream>>::connect(&addr)
                .await
                .unwrap();
            let c3 = WsStreamClient::<TlsStream<DataStream>>::connect(&addr)
                .await
                .unwrap();
            let connector = RawStreamClient::<TlsStream<DataStream>>::connect(&addr)
                .await
                .unwrap();
            let c1 = c.unary(vec![], "jafar").await;
            let c12 = connector.send(vec![]).await;
            (cb)((c1.is_ok() && c12.is_ok()) as u8);
        });
    }
}

struct TransporterEntry {}

/// Initialize global transporter (call once from Dart)
#[unsafe(no_mangle)]
pub extern "C" fn dart_transporter_init() {
    let mut guard = GLOBAL_TRANSPORTER.lock().unwrap();
    *guard = Some(DartTransporter::new());
}
#[unsafe(no_mangle)]
pub extern "C" fn dart_transporter_create() -> u32 {
    let mut guard = GLOBAL_TRANSPORTER.lock().unwrap();
    *guard = Some(DartTransporter::new());
    0
}
#[unsafe(no_mangle)]
pub extern "C" fn dart_transporter_send(request: DartCallbackC) -> u32 {
    let guard = GLOBAL_TRANSPORTER.lock().unwrap();
    let rf = guard.as_ref().unwrap();
    rf.tet(request);
    0
}
#[unsafe(no_mangle)]
pub extern "C" fn dart_transporter_destroy(transporter_id: u32) -> u8 {
    0
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn dart_transporter_free_memory(config: *const u8) -> u8 {
    0
}
