pub struct StreamUtils;
use arti_client::{StreamPrefs, TorClient, TorClientConfig};
use once_cell::sync::Lazy;
use rustls::ClientConfig;
use rustls_platform_verifier::ConfigVerifierExt;
use std::sync::Arc;
use tokio::{
    io::{AsyncRead, AsyncWrite},
    net::TcpStream,
    sync::OnceCell,
};
use tokio_rustls::{TlsConnector, client::TlsStream};
use tor_rtcompat::PreferredRuntime;

use crate::{
    stream::tls::TofuVerifier,
    types::{AddressInfo, error::ResultStatus},
    utils::Utils,
};

static RUSTLS_RING_PROVIDER: Lazy<()> = Lazy::new(|| {
    rustls::crypto::ring::default_provider()
        .install_default()
        .expect("failed to install rustls ring provider");
});
static TOR_CLIENT: OnceCell<TorClient<PreferredRuntime>> = OnceCell::const_new();

pub trait AsyncReadWrite: AsyncRead + AsyncWrite + Unpin + Send {}
impl<T: AsyncRead + AsyncWrite + Unpin + Send + 'static> AsyncReadWrite for T {}
// type BoxedStream = Box<dyn AsyncReadWrite>;

impl StreamUtils {
    pub async fn get_tor_client() -> TorClient<PreferredRuntime> {
        TOR_CLIENT
            .get_or_init(|| async {
                let config = TorClientConfig::default();
                TorClient::create_bootstrapped(config)
                    .await
                    .expect("tor bootstrap failed")
            })
            .await
            .clone()
    }

    pub fn ensure_rustls_provider() {
        let _ = *RUSTLS_RING_PROVIDER;
    }
    pub fn create_tls_config() -> Result<ClientConfig, ResultStatus> {
        StreamUtils::ensure_rustls_provider();
        ClientConfig::with_platform_verifier().map_err(ResultStatus::from)
    }
    pub fn create_no_verify_tls_config() -> Result<ClientConfig, ResultStatus> {
        StreamUtils::ensure_rustls_provider();
        Ok(ClientConfig::builder()
            .dangerous()
            .with_custom_certificate_verifier(Arc::new(TofuVerifier))
            .with_no_client_auth())
    }
    pub async fn create_tcp_stream(addr: &AddressInfo) -> Result<TcpStream, ResultStatus> {
        TcpStream::connect((addr.host.to_string(), addr.port))
            .await
            .map_err(|_| ResultStatus::NetError)
    }
    pub async fn create_tls_stream<T: AsyncReadWrite>(
        addr: &AddressInfo,
        stream: T,
    ) -> Result<TlsStream<T>, ResultStatus> {
        let connector = StreamUtils::create_tls_connector()?;
        let domain = Utils::get_server_name(&addr.host)?;
        let stream = connector
            .connect(domain, stream)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        Ok(stream)
    }
    pub async fn create_tls_stream_no_verify<T: AsyncReadWrite>(
        addr: &AddressInfo,
        stream: T,
    ) -> Result<TlsStream<T>, ResultStatus> {
        let connector = StreamUtils::create_no_verify_tls_connector()?;
        let domain = Utils::get_server_name(&addr.host)?;
        let stream = connector
            .connect(domain, stream)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        Ok(stream)
    }
    pub async fn create_tor_stream(
        addr: &AddressInfo,
    ) -> Result<arti_client::DataStream, ResultStatus> {
        let client = StreamUtils::get_tor_client().await;

        let mut prefs = StreamPrefs::new();
        prefs.ipv4_only();

        client
            .connect_with_prefs((addr.host.to_string(), addr.port), &prefs)
            .await
            .map_err(|e| {
                println!("create_tor_stream error: {:#?}", e);
                ResultStatus::TorNetError
            })
    }

    pub fn create_tls_connector() -> Result<TlsConnector, ResultStatus> {
        let tls_config = StreamUtils::create_tls_config()?;
        Ok(TlsConnector::from(Arc::new(tls_config)))
    }
    pub fn create_no_verify_tls_connector() -> Result<TlsConnector, ResultStatus> {
        let tls_config = StreamUtils::create_no_verify_tls_config()?;
        Ok(TlsConnector::from(Arc::new(tls_config)))
    }
}

#[async_trait::async_trait]
pub trait ConnectStream: AsyncRead + AsyncWrite + Unpin + Send + Sync + 'static {
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus>
    where
        Self: Sized;
}

#[async_trait::async_trait]
impl ConnectStream for TcpStream {
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        StreamUtils::create_tcp_stream(addr).await
    }
}

#[async_trait::async_trait]
impl ConnectStream for arti_client::DataStream {
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        StreamUtils::create_tor_stream(addr).await
    }
}

#[async_trait::async_trait]
impl<T> ConnectStream for TlsStream<T>
where
    T: ConnectStream + AsyncReadWrite,
{
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let base_stream = T::connect(addr).await?;
        StreamUtils::create_tls_stream(addr, base_stream).await
    }
}
