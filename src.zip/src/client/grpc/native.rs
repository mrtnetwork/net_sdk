use futures::stream;
use std::{marker::PhantomData, sync::Arc};
use tokio::sync::{Mutex, broadcast};
use tokio_tungstenite::tungstenite::http::uri::PathAndQuery;
use tonic::{client::Grpc, transport::Channel};

use crate::{
    client::{IClient, IGrpcClient, grpc::raw_codec::BufferCodec},
    stream::{ConnectStream, grpc::GrpcConnector},
    types::{AddressInfo, error::ResultStatus},
};

pub struct GrpcClient<T> {
    client: Arc<Mutex<Grpc<Channel>>>,
    _marker: PhantomData<T>,
}

#[async_trait::async_trait]
impl<T> IClient for GrpcClient<T>
where
    T: ConnectStream,
{
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let connector: GrpcConnector<T> = GrpcConnector::default();
        let endpoint: tonic::transport::Endpoint =
            tonic::transport::Endpoint::from_shared(addr.url.to_string()).unwrap();
        let channel = endpoint
            .connect_with_connector(connector)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        Ok(GrpcClient {
            client: Arc::new(Mutex::new(Grpc::new(channel))),
            _marker: PhantomData,
        })
    }
}
#[async_trait::async_trait]
impl<T> IGrpcClient for GrpcClient<T>
where
    T: ConnectStream,
{
    async fn unary(&self, buffer: Vec<u8>, method_name: &str) -> Result<Vec<u8>, ResultStatus> {
        let mut client = self.client.lock().await;
        let path = PathAndQuery::try_from(method_name.to_string())
            .map_err(|_| ResultStatus::InvalidGrpcMethodPath)?;
        let req = tonic::Request::new(buffer);
        let codec = BufferCodec::default();
        client.ready().await.map_err(|_| ResultStatus::NetError)?;
        let resp = client
            .unary(req, path, codec)
            .await
            .map_err(|_| ResultStatus::NetError)?;

        Ok(resp.into_inner())
    }

    async fn stream(
        &self,
        buffer: Vec<u8>,
        method_name: &str,
    ) -> Result<broadcast::Receiver<Result<Vec<u8>, ResultStatus>>, ResultStatus> {
        let (tx, rx) = broadcast::channel(128);

        let mut client = self.client.lock().await;
        let path = PathAndQuery::try_from(method_name.to_string())
            .map_err(|_| ResultStatus::InvalidGrpcMethodPath)?;
        let codec = BufferCodec::default();
        client.ready().await.map_err(|_| ResultStatus::NetError)?;

        let req_stream = stream::once(async { buffer });
        let req = tonic::Request::new(req_stream);
        client.ready().await.map_err(|_| ResultStatus::NetError)?;
        let stream = client
            .streaming(req, path, codec)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        let mut stream: tonic::Streaming<Vec<u8>> = stream.into_inner();
        let tx_clone = tx.clone();
        tokio::spawn(async move {
            while let Some(msg) = stream.message().await.unwrap_or(None) {
                let _ = tx_clone.send(Ok(msg.to_vec()));
            }
        });

        Ok(rx)
    }
}
