use crate::{
    client::{IClient, IStreamClient},
    stream::ConnectStream,
    types::{AddressInfo, error::ResultStatus},
};
use futures::{SinkExt, StreamExt, stream::SplitSink};
use tokio::sync::broadcast;
use tokio_tungstenite::{WebSocketStream, tungstenite::Message};

pub struct WsStreamClient<T> {
    writer: tokio::sync::Mutex<SplitSink<WebSocketStream<Box<T>>, Message>>,
    incoming: broadcast::Sender<Result<Vec<u8>, ResultStatus>>,
}
#[async_trait::async_trait]
impl<T> IClient for WsStreamClient<T>
where
    T: ConnectStream,
{
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let stream = T::connect(addr).await?;

        let boxed_stream: Box<T> = Box::new(stream);
        let (ws_stream, _response) =
            tokio_tungstenite::client_async(addr.url.to_string(), boxed_stream)
                .await
                .map_err(|_| ResultStatus::NetError)?;
        let (write, read) = ws_stream.split();
        let (tx, _) = broadcast::channel(128);
        let ws_reader = tokio::sync::Mutex::new(read);
        let tx_clone = tx.clone();
        tokio::spawn(async move {
            use tokio_tungstenite::tungstenite::Message;

            loop {
                let msg = ws_reader.lock().await.next().await;
                match msg {
                    Some(Ok(Message::Binary(data))) => {
                        let _ = tx_clone.send(Ok(data.to_vec()));
                    }
                    Some(Ok(_)) => {}
                    Some(Err(_)) | None => {
                        let _ = tx_clone.send(Err(ResultStatus::NetError));
                        break;
                    }
                }
            }
        });

        Ok(Self {
            incoming: tx,
            writer: tokio::sync::Mutex::new(write),
        })
    }
}
#[async_trait::async_trait]
impl<T> IStreamClient for WsStreamClient<T>
where
    T: ConnectStream,
{
    async fn send(&self, data: Vec<u8>) -> Result<(), ResultStatus> {
        use tokio_tungstenite::tungstenite::Message;

        let mut ws = self.writer.lock().await;
        ws.send(Message::Binary(data.into()))
            .await
            .map_err(|_| ResultStatus::NetError)
    }

    fn subscribe(&self) -> broadcast::Receiver<Result<Vec<u8>, ResultStatus>> {
        self.incoming.subscribe()
    }
}
