use tokio::sync::broadcast;

use crate::types::{
    AddressInfo,
    error::ResultStatus,
    response::{HttpConfig, HttpResponse},
};

pub mod grpc;
pub mod http;
pub mod raw;
pub mod websocket;

#[async_trait::async_trait]
pub trait IClient {
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus>
    where
        Self: Sized;
}

#[async_trait::async_trait]
pub trait IStreamClient {
    /// Send raw bytes
    async fn send(&self, data: Vec<u8>) -> Result<(), ResultStatus>;

    /// Subscribe to incoming messages (Dart-style stream)
    fn subscribe(&self) -> broadcast::Receiver<Result<Vec<u8>, ResultStatus>>;
}
#[async_trait::async_trait]
pub trait IGrpcClient {
    /// Send raw bytes
    async fn unary(&self, buffer: Vec<u8>, method_name: &str) -> Result<Vec<u8>, ResultStatus>;

    /// Send a streaming RPC and receive a broadcast channel for multiple messages
    async fn stream(
        &self,
        buffer: Vec<u8>,
        method_name: &str,
    ) -> Result<broadcast::Receiver<Result<Vec<u8>, ResultStatus>>, ResultStatus>;
}

#[async_trait::async_trait]
pub trait IHttpClient {
    async fn get(&self, url: &str, config: HttpConfig) -> Result<HttpResponse, ResultStatus>;
    async fn post(
        &self,
        url: &str,
        body: Vec<u8>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus>;
    async fn delete(
        &self,
        url: &str,
        body: Vec<u8>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus>;
    async fn update(
        &self,
        url: &str,
        body: Vec<u8>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus>;
}
