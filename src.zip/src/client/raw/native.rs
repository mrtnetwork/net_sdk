use tokio::{io::split, sync::broadcast};

use crate::{
    client::{IClient, IStreamClient},
    stream::ConnectStream,
    types::{AddressInfo, error::ResultStatus},
};

pub struct RawStreamClient<T> {
    incoming: broadcast::Sender<Result<Vec<u8>, ResultStatus>>,
    writer: tokio::sync::Mutex<tokio::io::WriteHalf<T>>,
}
#[async_trait::async_trait]
impl<T> IClient for RawStreamClient<T>
where
    T: ConnectStream,
{
    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let stream = T::connect(addr).await?;
        let (reader, writer) = split(stream);
        let (tx, _) = broadcast::channel(128);
        // background reader task
        let tx_clone = tx.clone();
        tokio::spawn(async move {
            let mut reader = reader;
            let mut buf = [0u8; 4096];

            loop {
                match tokio::io::AsyncReadExt::read(&mut reader, &mut buf).await {
                    Ok(0) => break,
                    Ok(n) => {
                        let _ = tx_clone.send(Ok(buf[..n].to_vec()));
                    }
                    Err(_) => {
                        let _ = tx_clone.send(Err(ResultStatus::NetError));
                        break;
                    }
                }
            }
        });
        Ok(Self {
            incoming: tx,
            writer: tokio::sync::Mutex::new(writer),
        })
    }
}

#[async_trait::async_trait]
impl<T> IStreamClient for RawStreamClient<T>
where
    T: ConnectStream,
{
    async fn send(&self, data: Vec<u8>) -> Result<(), ResultStatus> {
        use tokio::io::AsyncWriteExt;

        let mut writer = self.writer.lock().await;
        writer
            .write_all(&data)
            .await
            .map_err(|_| ResultStatus::NetError)
    }

    fn subscribe(&self) -> broadcast::Receiver<Result<Vec<u8>, ResultStatus>> {
        self.incoming.subscribe()
    }
}
