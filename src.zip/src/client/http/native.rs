use std::{marker::PhantomData, str::FromStr};

use async_trait::async_trait;
use bytes::Bytes;
use http_body_util::{BodyExt, Full};
use hyper::{
    Error, Method, Request, Response, Uri,
    body::Incoming,
    client::conn::{http1, http2},
    service::service_fn,
};
use hyper_util::rt::TokioIo;
use hyper_util::server::conn::auto::Builder;

use crate::{
    client::{IClient, IHttpClient, http::executor::TokioExecutor},
    stream::ConnectStream,
    types::{
        self, AddressInfo,
        error::ResultStatus,
        response::{HttpConfig, HttpResponse},
    },
};

#[async_trait]
pub trait SendRequestExt: Send + Sync {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error>;
}

// Implement for HTTP/1 SendRequest
#[async_trait]
impl SendRequestExt for http1::SendRequest<Full<Bytes>> {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error> {
        self.send_request(req).await
    }
}

#[async_trait]
impl SendRequestExt for http2::SendRequest<Full<Bytes>> {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error> {
        self.send_request(req).await
    }
}
#[async_trait]
pub trait Connect: Sized {
    async fn connect<T: ConnectStream>(addr: &AddressInfo) -> Result<Self, ResultStatus>;
}
#[async_trait]
impl Connect for http1::SendRequest<Full<Bytes>> {
    async fn connect<T: ConnectStream>(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let stream = T::connect(addr).await?;
        let tokio = TokioIo::new(stream);

        let (sender, _) = hyper::client::conn::http1::handshake(tokio)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        Ok(sender)
    }
}
#[async_trait]
impl Connect for http2::SendRequest<Full<Bytes>> {
    async fn connect<T: ConnectStream>(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let stream = T::connect(addr).await?;
        let tokio = TokioIo::new(stream);
        // Builder::new(TokioExecutor).serve_connection(tokio, service_fn(f));
        let (sender, _) = hyper::client::conn::http2::handshake(TokioExecutor, tokio)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        Ok(sender)
    }
}

pub struct HttpClient<T, E> {
    sender: tokio::sync::Mutex<Option<Box<dyn SendRequestExt>>>,
    _stream_marker: PhantomData<T>,
    _protocol_marker: PhantomData<E>,
}
#[async_trait::async_trait]
impl<T, E> IClient for HttpClient<T, E>
where
    T: ConnectStream,
    E: SendRequestExt + Connect + 'static,
{
    // pub fn default(){
    //     HttpClient
    // }

    async fn connect(addr: &AddressInfo) -> Result<Self, ResultStatus> {
        let sender: E = E::connect::<T>(addr).await?;

        Ok(HttpClient {
            sender: Box::new(sender),
            _stream_marker: PhantomData,
            _protocol_marker: PhantomData,
        })
    }
}

#[async_trait::async_trait]
impl<T, E> IHttpClient for HttpClient<T, E>
where
    T: ConnectStream,
    E: SendRequestExt + Connect + 'static,
{
    async fn get(&mut self, url: &str, config: HttpConfig) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::GET, url, None, config).await
    }

    async fn post(
        &mut self,
        url: &str,
        body: Vec<u8>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::POST, url, Some(body), config).await
    }

    async fn delete(
        &mut self,
        url: &str,
        body: Vec<u8>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::DELETE, url, Some(body), config).await
    }

    async fn update(
        &mut self,
        url: &str,
        body: Vec<u8>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::PUT, url, Some(body), config).await
    }
}

impl<T, E> HttpClient<T, E>
where
    T: ConnectStream,
    E: SendRequestExt + Connect + 'static,
{
    async fn request(
        &mut self,
        method: Method,
        url: &str,
        body: Option<Vec<u8>>,
        config: HttpConfig,
    ) -> Result<HttpResponse, ResultStatus> {
        let uri = Uri::from_str(url).unwrap();
        let mut builder = Request::builder().method(method).uri(uri);

        builder = apply_config(builder, config);

        let body = match body {
            Some(b) => Full::new(Bytes::from(b)),
            None => Full::new(Bytes::new()),
        };

        let req = builder.body(body).map_err(|_| ResultStatus::NetError)?;

        let resp = self
            .sender
            .send(req)
            .await
            .map_err(|_| ResultStatus::NetError)?;

        let status_code = resp.status().as_u16();
        let body = read_body(resp.into_body()).await?;

        Ok(HttpResponse { status_code, body })
    }
}

async fn read_body(mut body: Incoming) -> Result<Vec<u8>, ResultStatus> {
    let mut out = Vec::new();
    while let Some(frame) = body.frame().await {
        let frame = frame.map_err(|_| ResultStatus::NetError)?;
        if let Some(data) = frame.data_ref() {
            out.extend_from_slice(data);
        }
    }

    Ok(out)
}
fn apply_config(mut builder: http::request::Builder, config: HttpConfig) -> http::request::Builder {
    for h in config.headers {
        builder = builder.header(h.key, h.value);
    }

    if let Some(auth) = config.auth {
        builder = builder.header(
            http::header::AUTHORIZATION,
            format!("{} {}", auth.key, auth.value),
        );
    }
    // Http::new();

    // Digest auth would be implemented here (nonce handling etc.)
    builder
}
