use std::sync::Arc;

use crate::{
    client::{IClient, IStreamClient},
    stream::ConnectStream,
    types::{error::ResultStatus, response::NetConfig},
};
use bytes::Bytes;
use futures::{SinkExt, StreamExt, stream::SplitSink};
use tokio::{
    sync::{Mutex, broadcast},
    task::JoinHandle,
};
use tokio_tungstenite::{WebSocketStream, client_async, tungstenite::Message};
struct WriterWithHandler<T> {
    pub writer: SplitSink<WebSocketStream<Box<T>>, Message>,
    pub handler: JoinHandle<()>,
}
impl<T> WriterWithHandler<T>
where
    T: ConnectStream,
{
    async fn send(&mut self, data: &[u8]) -> Result<(), ResultStatus> {
        self.writer
            .send(Message::Binary(Bytes::copy_from_slice(data)))
            .await
            .map_err(|_| ResultStatus::NetError)
    }
    async fn close(&mut self) {
        // 1. Send WS close frame (protocol-level)
        let _ = self.writer.send(Message::Close(None)).await;
        // 2. Stop reader task
        self.handler.abort();

        // 3. Finish WS close handshake
        let _ = self.writer.close().await;
    }
}
pub struct WsStreamClient<T> {
    writer: Arc<Mutex<Option<WriterWithHandler<T>>>>,
    incoming: broadcast::Sender<Result<Vec<u8>, ResultStatus>>,
    config: NetConfig,
}

impl<T> WsStreamClient<T>
where
    T: ConnectStream,
{
    pub fn default(config: &NetConfig) -> Result<Self, ResultStatus> {
        let (tx, _) = broadcast::channel(128);
        Ok(Self {
            incoming: tx,
            writer: Arc::new(Mutex::new(None)),
            config: config.clone(),
        })
    }
}
#[async_trait::async_trait]
impl<T> IClient for WsStreamClient<T>
where
    T: ConnectStream,
{
    type Stream = SplitSink<WebSocketStream<Box<T>>, Message>;
    async fn connect(&self) -> Result<(), ResultStatus> {
        let mut guard = self.writer.lock().await;

        if guard.is_some() {
            return Ok(()); // already connected
        }

        // Connect raw stream
        let stream = T::connect(&self.config)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        let boxed_stream: Box<T> = Box::new(stream);

        // Connect WebSocket
        let (ws_stream, _response) = client_async(self.config.addr.url.clone(), boxed_stream)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        let (write, mut read) = ws_stream.split();

        // Spawn background reader
        let tx_clone = self.incoming.clone();
        let writer_mutex = Arc::clone(&self.writer);

        let handler = tokio::spawn(async move {
            loop {
                let msg = read.next().await;
                match msg {
                    Some(Ok(Message::Binary(data))) => {
                        let _ = tx_clone.send(Ok(data.to_vec()));
                    }
                    Some(Ok(_)) => {}
                    Some(Err(_)) | None => {
                        let _ = tx_clone.send(Err(ResultStatus::NetError));
                        // On disconnect, set writer to None
                        let mut guard = writer_mutex.lock().await;
                        *guard = None;
                        break;
                    }
                }
            }
        });
        // Save writer in mutex
        *guard = Some(WriterWithHandler {
            writer: write,
            handler: handler,
        });

        Ok(())
    }

    fn get_config(&self) -> NetConfig {
        return self.config.clone();
    }

    fn default(config: &NetConfig) -> Result<Self, ResultStatus> {
        let (tx, _) = broadcast::channel(128);
        Ok(Self {
            writer: Arc::new(Mutex::new(None)),
            incoming: tx,
            config: config.clone(),
        })
    }
}
#[async_trait::async_trait]
impl<T> IStreamClient for WsStreamClient<T>
where
    T: ConnectStream,
{
    async fn send<'a>(&self, data: &'a [u8]) -> Result<(), ResultStatus> {
        self.connect().await?; // ensure connected
        let mut guard = self.writer.lock().await;

        if let Some(writer) = guard.as_mut() {
            writer.send(&data).await.map_err(|_| ResultStatus::NetError)
        } else {
            Err(ResultStatus::NetError)
        }
    }

    async fn subscribe(
        &self,
    ) -> Result<broadcast::Receiver<Result<Vec<u8>, ResultStatus>>, ResultStatus> {
        self.connect().await?;
        Ok(self.incoming.subscribe())
    }
    async fn close(&self) {
        let mut guard = self.writer.lock().await;
        if let Some(writer) = guard.as_mut() {
            let _ = writer.close().await;
        }
        *guard = None
    }
}
