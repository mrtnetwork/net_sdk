use futures::stream;
use std::{marker::PhantomData, sync::Arc};
use tokio::sync::{Mutex, broadcast, oneshot};
use tokio_tungstenite::tungstenite::http::uri::PathAndQuery;
use tonic::{Code, client::Grpc, transport::Channel};

use crate::{
    client::{GrpcStreamHandle, IClient, IGrpcClient, grpc::raw_codec::BufferCodec},
    stream::{ConnectStream, grpc::GrpcConnector},
    types::{error::ResultStatus, response::NetConfig},
};

pub struct GrpcClient<'a, T> {
    client: Arc<Mutex<Option<Grpc<Channel>>>>,
    config: NetConfig<'a>,
    _marker: PhantomData<T>,
}
impl<'a, T> GrpcClient<'a, T>
where
    T: ConnectStream,
{
    pub fn default(config: &'a NetConfig<'a>) -> Result<Self, ResultStatus> {
        Ok(Self {
            client: Arc::new(Mutex::new(None)),
            config: config.clone(),
            _marker: PhantomData,
        })
    }
}
#[async_trait::async_trait]
impl<'a, T> IClient<'a> for GrpcClient<'a, T>
where
    T: ConnectStream,
{
    type Stream = Grpc<T>;
    async fn connect(&self) -> Result<(), ResultStatus> {
        let mut guard = self.client.lock().await;

        let reconnect_needed = match guard.as_mut() {
            Some(client) => client.ready().await.is_err(),
            None => true,
        };
        println!("need {:#?}", self.config.addr.url);
        if reconnect_needed {
            // Create new channel
            let endpoint = tonic::transport::Endpoint::from_shared(self.config.addr.url.clone())
                .map_err(|e| {
                    println!("error {:#?}", e);
                    ResultStatus::NetError
                })?;
            let connector = GrpcConnector::<T>::default();
            let channel = endpoint
                .connect_with_connector(connector)
                .await
                .map_err(|e| {
                    println!("error {:#?}", e);
                    ResultStatus::NetError
                })?;

            // Replace the client inside the mutex
            *guard = Some(Grpc::new(channel));
            println!("seet cannel!");
        }

        Ok(())
    }

    fn get_config(&self) -> NetConfig<'a> {
        return self.config.clone();
    }

    fn default(config: &'a NetConfig<'a>) -> Result<Self, ResultStatus> {
        Ok(Self {
            client: Arc::new(Mutex::new(None)),
            config: config.clone(),
            _marker: PhantomData,
        })
    }
}
#[async_trait::async_trait]
impl<'a, T> IGrpcClient<'a> for GrpcClient<'a, T>
where
    T: ConnectStream,
{
    async fn unary(&self, buffer: &'a [u8], method_name: &'a str) -> Result<Vec<u8>, ResultStatus> {
        // Ensure client exists and is ready
        self.connect().await?;

        // Lock mutex to get client
        let mut guard = self.client.lock().await;
        let client = guard.as_mut().ok_or(ResultStatus::NetError)?; // should exist after connect()

        let path = PathAndQuery::try_from(method_name.to_string())
            .map_err(|_| ResultStatus::InvalidGrpcMethodPath)?;
        let req = tonic::Request::new(buffer);
        let codec = BufferCodec::default();

        client.ready().await.map_err(|e| {
            println!("error {:#?}", e);
            ResultStatus::NetError
        })?;
        let resp = client.unary(req, path, codec).await.map_err(|e| {
            println!("error {:#?}", e);
            ResultStatus::NetError
        })?;
        Ok(resp.into_inner())
    }

    async fn stream(
        &self,
        buffer: &'a [u8],
        method_name: &'a str,
    ) -> Result<GrpcStreamHandle, ResultStatus> {
        self.connect().await?;

        let (tx, rx) = broadcast::channel(128);
        let (cancel_tx, mut cancel_rx) = oneshot::channel::<()>();
        // Lock mutex to get client
        let mut guard = self.client.lock().await;
        let client = guard.as_mut().ok_or(ResultStatus::NetError)?; // should exist after connect()

        let path = PathAndQuery::try_from(method_name.to_string())
            .map_err(|_| ResultStatus::InvalidGrpcMethodPath)?;
        let codec = BufferCodec::default();

        let req_stream = stream::once(async { buffer });
        let req = tonic::Request::new(req_stream);

        client.ready().await.map_err(|_| ResultStatus::NetError)?;
        let stream = client
            .streaming(req, path, codec)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        let mut stream: tonic::Streaming<Vec<u8>> = stream.into_inner();

        let tx_clone = tx.clone();
        tokio::spawn(async move {
            loop {
                tokio::select! {
                    _ = &mut cancel_rx => {
                        // cancel requested
                        break;
                    }
                    msg = stream.message() => {
                        match msg {
                            Ok(Some(msg)) => {
                                let _ = tx_clone.send(Ok(Some(msg.to_vec())));
                            },
                            Ok(None) => {
                                let _ = tx_clone.send(Ok(None));
                                break;
                            }
                            Err(err) => {
                                     if err.code()==Code::Ok{
                                          let _ = tx_clone.send(Err(ResultStatus::StreamError));

                                     }else{
                                         let _ = tx_clone.send(Err(ResultStatus::StreamError));
                                     }
                                    break;

                            }

                        }
                    }
                }
            }
        });

        Ok(GrpcStreamHandle {
            rx,
            cancel: cancel_tx,
        })
    }
}
