use crate::{
    client::{IClient, IHttpClient, http::executor::TokioExecutor},
    stream::ConnectStream,
    types::{
        error::ResultStatus,
        response::{HttpConfig, HttpProtocol, HttpResponse, NetConfig},
    },
};
use async_trait::async_trait;
use bytes::Bytes;
use http_body_util::{BodyExt, Full};
use hyper::{
    Error, Method, Request, Response, Uri,
    body::Incoming,
    client::conn::{http1, http2},
};
use hyper_util::rt::TokioIo;
use std::{marker::PhantomData, str::FromStr, sync::Arc};
use tokio::sync::Mutex;

#[async_trait]
pub trait SendRequestExt: Send + Sync {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error>;
    fn protocol(&self) -> HttpProtocol;
}

// Implement for HTTP/1 SendRequest
#[async_trait]
impl SendRequestExt for http1::SendRequest<Full<Bytes>> {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error> {
        self.send_request(req).await
    }
    fn protocol(&self) -> HttpProtocol {
        HttpProtocol::Http1
    }
}

#[async_trait]
impl SendRequestExt for http2::SendRequest<Full<Bytes>> {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error> {
        self.send_request(req).await
    }
    fn protocol(&self) -> HttpProtocol {
        HttpProtocol::Http2
    }
}
#[async_trait]
pub trait Connect: Sized {
    async fn connect<T: ConnectStream>(addr: &NetConfig) -> Result<Self, ResultStatus>;
}
#[async_trait]
impl Connect for http1::SendRequest<Full<Bytes>> {
    async fn connect<T: ConnectStream>(addr: &NetConfig) -> Result<Self, ResultStatus> {
        let stream = T::connect(addr).await?;
        println!("tls created!");

        let tokio = TokioIo::new(stream);
        let (sender, connection) = hyper::client::conn::http1::handshake(tokio)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        println!("handshake done!");
        tokio::spawn(async move {
            if let Err(e) = connection.await {
                println!("HTTP/1 connection error: {:?}", e);
            }
        });
        Ok(sender)
    }
}
#[async_trait]
impl Connect for http2::SendRequest<Full<Bytes>> {
    async fn connect<T: ConnectStream>(addr: &NetConfig) -> Result<Self, ResultStatus> {
        let stream = T::connect(addr).await?;
        let tokio = TokioIo::new(stream);
        // Builder::new(TokioExecutor).serve_connection(tokio, service_fn(f));
        let (sender, connection) = hyper::client::conn::http2::handshake(TokioExecutor, tokio)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        println!("this is work!");
        tokio::spawn(async move {
            if let Err(e) = connection.await {
                println!("HTTP/2 connection error: {:?}", e);
            }
        });
        Ok(sender)
    }
}

pub struct AutoSendRequest {
    inner: Box<dyn SendRequestExt>,
}

#[async_trait]
impl Connect for AutoSendRequest {
    async fn connect<T: ConnectStream>(config: &NetConfig) -> Result<Self, ResultStatus> {
        let stream = T::connect(config).await?;
        let alpn = stream.alpn_protocol();
        if let Some(proto) = alpn {
            if proto == b"h2" {
                if let Ok(sender) = http2::SendRequest::<Full<Bytes>>::connect::<T>(config).await {
                    return Ok(Self {
                        inner: Box::new(sender),
                    });
                }
            }
        }
        let sender = http1::SendRequest::<Full<Bytes>>::connect::<T>(config).await?;

        Ok(Self {
            inner: Box::new(sender),
        })
    }
}
#[async_trait]
impl SendRequestExt for AutoSendRequest {
    async fn send(
        &mut self,
        req: Request<Full<Bytes>>,
    ) -> Result<Response<hyper::body::Incoming>, Error> {
        self.inner.send(req).await
    }
    fn protocol(&self) -> HttpProtocol {
        self.inner.protocol()
    }
}
pub struct HttpClient<T, E> {
    sender: Arc<Mutex<Option<Box<dyn SendRequestExt>>>>,
    _stream_marker: PhantomData<T>,
    _protocol_marker: PhantomData<E>,
    config: NetConfig,
}
#[async_trait::async_trait]
impl<T, E> IClient for HttpClient<T, E>
where
    T: ConnectStream,
    E: SendRequestExt + Connect + 'static,
{
    type Stream = Box<dyn SendRequestExt>;
    async fn connect(&self) -> Result<(), ResultStatus> {
        let mut guard = self.sender.lock().await;

        let reconnect_needed = match guard.as_mut() {
            Some(_) => false, // sender exists, assume ready
            None => true,
        };

        if reconnect_needed {
            let sender: E = E::connect::<T>(&self.config).await?;
            *guard = Some(Box::new(sender));
        }

        Ok(())
    }
    fn get_config(&self) -> NetConfig {
        self.config.clone()
    }

    fn default(config: &NetConfig) -> Result<Self, ResultStatus> {
        Ok(Self {
            sender: Arc::new(Mutex::new(None)),
            _stream_marker: PhantomData,
            _protocol_marker: PhantomData,
            config: config.clone(),
        })
    }
}

#[async_trait::async_trait]
impl<T, E> IHttpClient for HttpClient<T, E>
where
    T: ConnectStream,
    E: SendRequestExt + Connect + 'static,
{
    async fn get(&self, url: &str) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::GET, url, None).await
    }

    async fn post(&self, url: &str, body: Vec<u8>) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::POST, url, Some(body)).await
    }

    async fn delete(&self, url: &str, body: Vec<u8>) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::DELETE, url, Some(body)).await
    }

    async fn update(&self, url: &str, body: Vec<u8>) -> Result<HttpResponse, ResultStatus> {
        self.request(Method::PUT, url, Some(body)).await
    }
}

impl<T, E> HttpClient<T, E>
where
    T: ConnectStream,
    E: SendRequestExt + Connect + 'static,
{
    async fn request(
        &self,
        method: Method,
        url: &str,
        body: Option<Vec<u8>>,
    ) -> Result<HttpResponse, ResultStatus> {
        self.connect().await?;
        let config = self.config.http.clone().unwrap_or(HttpConfig::default());
        let uri = Uri::from_str(url).unwrap();
        let host = uri.host().ok_or(ResultStatus::NetError)?.to_string();
        let mut builder = Request::builder().method(method).uri(uri);
        builder = apply_config(builder, config);
        let body = match body {
            Some(b) => Full::new(Bytes::from(b)),
            None => Full::new(Bytes::new()),
        };
        let mut guard = self.sender.lock().await;
        let sender = guard.as_mut().ok_or(ResultStatus::NetError)?;
        let protocol = sender.protocol();
        match protocol {
            HttpProtocol::Http1 => {
                builder = builder.header(http::header::HOST, host);
            }
            HttpProtocol::Http2 => {}
        };
        let req = builder.body(body).map_err(|_| ResultStatus::NetError)?;
        match sender.send(req.clone()).await {
            Ok(resp) => read_response(resp).await,
            Err(e) => {
                // reconnect and retry once
                println!("Connection dead, reconnecting {:#?}", e);
                *guard = Some(Box::new(E::connect::<T>(&self.config).await?));
                let sender = guard.as_mut().unwrap();
                let resp = sender.send(req).await.map_err(|_| ResultStatus::NetError)?;
                read_response(resp).await
            }
        }
    }
}
async fn read_response(resp: Response<Incoming>) -> Result<HttpResponse, ResultStatus> {
    let status_code = resp.status().as_u16();
    let body = read_body(resp.into_body()).await?;
    Ok(HttpResponse { status_code, body })
}
async fn read_body(mut body: Incoming) -> Result<Vec<u8>, ResultStatus> {
    let mut out = Vec::new();
    while let Some(frame) = body.frame().await {
        let frame = frame.map_err(|_| ResultStatus::NetError)?;
        if let Some(data) = frame.data_ref() {
            out.extend_from_slice(data);
        }
    }

    Ok(out)
}
fn apply_config(mut builder: http::request::Builder, config: HttpConfig) -> http::request::Builder {
    for h in config.headers {
        builder = builder.header(h.key, h.value);
    }
    if let Some(auth) = config.auth {
        builder = builder.header(
            http::header::AUTHORIZATION,
            format!("{} {}", auth.key, auth.value),
        );
    }
    builder
}

// #[cfg(test)]
mod tests {
    use std::vec;

    use crate::{
        types::response::{NetMode, NetProtocol},
        utils::Utils,
    };

    use super::*;
    use arti_client::DataStream;
    use hyper_util::client;
    // imports your tor_connect or check_tor_ip
    use tokio::{self, net::TcpStream};
    use tokio_rustls::client::TlsStream;
    use url::Url; // async runtime for #[tokio::test]
    #[tokio::test]
    async fn test_check_tor_ip() {
        // let bl =Request::builder().method(method).uri(uri).;
        let url = "https://check.torproject.org/api/ip";
        let addr = Utils::parse_http_url(url).unwrap();
        let config = NetConfig {
            addr: addr,
            mode: NetMode::Clearnet,
            http: None,
            protocol: NetProtocol::Http,
        };
        println!("success!");
        let r: HttpClient<TlsStream<TcpStream>, http1::SendRequest<Full<Bytes>>> =
            HttpClient::default(&config).unwrap();
        let result = r.get(url).await.unwrap();

        // let result = r.get(url).await.unwrap();
        println!("data {:#?}", String::from_utf8_lossy(&result.body));
        println!("rs {:#?}", result.status_code);
    }
}
