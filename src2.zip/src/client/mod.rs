use tokio::sync::{broadcast, oneshot};

use crate::types::{
    error::ResultStatus,
    response::{HttpResponse, NetConfig},
};

pub mod grpc;
pub mod http;
pub mod raw;
pub mod websocket;

#[async_trait::async_trait]
pub trait IClient<'a> {
    type Stream;
    async fn connect(&self) -> Result<(), ResultStatus>;
    fn get_config(&self) -> NetConfig<'a>;
    fn default(config: &'a NetConfig<'a>) -> Result<Self, ResultStatus>
    where
        Self: Sized;
}

#[async_trait::async_trait]
pub trait IStreamClient: Send + Sync + 'static {
    /// Send raw bytes
    async fn send<'a>(&self, data: &'a [u8]) -> Result<(), ResultStatus>;

    /// Subscribe to incoming messages (Dart-style stream)
    async fn subscribe(
        &self,
    ) -> Result<broadcast::Receiver<Result<Vec<u8>, ResultStatus>>, ResultStatus>;

    async fn close(&self);
}

pub struct GrpcStreamHandle {
    pub rx: broadcast::Receiver<Result<Option<Vec<u8>>, ResultStatus>>,
    cancel: oneshot::Sender<()>,
}
impl GrpcStreamHandle {
    pub fn cancel(self) {
        let _ = self.cancel.send(());
    }
}
#[async_trait::async_trait]
pub trait IGrpcClient<'a>: Send + Sync {
    /// Send raw bytes
    async fn unary(&self, buffer: &'a [u8], method_name: &'a str) -> Result<Vec<u8>, ResultStatus>;

    /// Send a streaming RPC and receive a broadcast channel for multiple messages
    async fn stream(
        &self,
        buffer: &'a [u8],
        method_name: &'a str,
    ) -> Result<GrpcStreamHandle, ResultStatus>;
}

#[async_trait::async_trait]
pub trait IHttpClient {
    async fn get(&self, url: &str) -> Result<HttpResponse, ResultStatus>;
    async fn post(&self, url: &str, body: Vec<u8>) -> Result<HttpResponse, ResultStatus>;
    async fn delete(&self, url: &str, body: Vec<u8>) -> Result<HttpResponse, ResultStatus>;
    async fn update(&self, url: &str, body: Vec<u8>) -> Result<HttpResponse, ResultStatus>;
}
