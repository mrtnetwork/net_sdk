use std::fmt;

#[repr(u32)]
#[derive(Debug, Clone)]
pub enum ResultStatus {
    OK = 1000,
    InvalidUrl = 1,
    TlsError = 2,
    NetError = 3,
    TorNetError = 4,
    InvalidServerName = 5,
    InvalidGrpcMethodPath = 6,
    InvalidHttpParams = 7,
    InvalidWebSocketParams = 8,
    InvalidProtocolParams = 9,
    SocketClosed = 10,
    SocketUnsubscribe = 11,
    StreamError = 12,
    StreamComplete = 13,
    InvalidSocketRequest = 14,
    InvalidGrpcRequset = 15,
}

impl fmt::Display for ResultStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?}", self)
    }
}

impl std::error::Error for ResultStatus {}
