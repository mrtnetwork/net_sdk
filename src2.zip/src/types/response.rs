use crate::{
    types::{AddressInfo, error::ResultStatus},
    utils::Utils,
};

#[derive(Clone)]
pub enum NetMode {
    Tor,
    Clearnet,
}

#[derive(Clone)]
pub enum HttpProtocol {
    Http1,
    Http2,
}

#[derive(Clone, PartialEq)]
pub enum NetProtocol {
    Http,
    Grpc,
    WebSocket,
    Socket,
}

#[derive(Clone, Debug)]
pub struct HttpResponse {
    pub status_code: u16,
    pub body: Vec<u8>, // still owned
}

#[derive(Clone)]
pub struct HttpHeader<'a> {
    pub key: &'a str,
    pub value: &'a str,
}

#[derive(Clone)]
pub struct HttpAuth<'a> {
    pub key: &'a str,
    pub value: &'a str,
}

#[derive(Clone)]
pub struct HttpDigestAuth<'a> {
    pub key: &'a str,
    pub value: &'a str,
}

#[derive(Clone)]
pub struct HttpConfig<'a> {
    pub headers: Vec<HttpHeader<'a>>,
    pub auth: Option<HttpAuth<'a>>,
    pub digest_auth: Option<HttpDigestAuth<'a>>,
}

#[derive(Clone)]
pub struct NetConfig<'a> {
    pub addr: AddressInfo,
    pub mode: NetMode,
    pub http: Option<HttpConfig<'a>>,
    pub protocol: NetProtocol,
}

impl<'a> Default for HttpConfig<'a> {
    fn default() -> HttpConfig<'a> {
        Self {
            headers: Vec::new(),
            auth: None,
            digest_auth: None,
        }
    }
}

pub struct NetRequestConfig<'a> {
    pub url: &'a str,
    pub mode: NetMode,
    pub protocol: NetProtocol,
    pub http: Option<HttpConfig<'a>>,
}

impl<'a> NetRequestConfig<'a> {
    fn to_protocol_address(&self) -> Result<AddressInfo, ResultStatus> {
        match self.protocol {
            NetProtocol::Http => Utils::parse_http_url(self.url),
            NetProtocol::Grpc => Utils::parse_http_url(self.url),
            NetProtocol::WebSocket => Utils::parse_ws_url(self.url),
            NetProtocol::Socket => Utils::parse_tcp_url(self.url),
        }
    }

    pub fn to_config(&self) -> Result<NetConfig<'a>, ResultStatus> {
        let addr = self.to_protocol_address()?;
        Ok(NetConfig {
            addr,
            http: self.http.clone(),
            protocol: self.protocol.clone(),
            mode: self.mode.clone(),
        })
    }

    pub fn to_protocol_config(&self, protocol: NetProtocol) -> Result<NetConfig<'a>, ResultStatus> {
        if self.protocol != protocol {
            return Err(ResultStatus::InvalidProtocolParams);
        }
        let addr = self.to_protocol_address()?;
        Ok(NetConfig {
            addr,
            http: self.http.clone(),
            protocol: self.protocol.clone(),
            mode: self.mode.clone(),
        })
    }
}

/// response

pub struct SocketStreamResponse {
    pub data: Vec<u8>,
}

pub enum ResponseKind {
    Status(ResultStatus),
    Socket(SocketStreamResponse),
    Grpc(GrpcResponse),
}
pub struct GrpcStreamIdResponse {
    pub id: u32,
}
pub struct GrpcStreamResponse {
    pub id: u32,
    pub data: Vec<u8>,
}
pub struct GrpcUnaryResponse {
    pub data: Vec<u8>,
}
pub enum GrpcResponse {
    Unary(GrpcUnaryResponse),
    StreamId(GrpcStreamIdResponse),
    Stream(GrpcStreamResponse),
}

pub struct Response {
    pub transport_id: u32,
    pub request_id: u32,
    pub response: ResponseKind,
}
