use crate::types::error::ResultStatus;

#[derive(Debug, Clone)]
pub struct GrpcRequestUnary<'a> {
    pub method: &'a str,
    pub data: &'a [u8],
}

#[derive(Debug, Clone)]
pub struct GrpcRequestStream<'a> {
    pub method: &'a str,
    pub data: &'a [u8],
}

#[derive(Debug, Clone, Copy)]
pub struct GrpcRequestUnsubscribe {
    pub id: u32,
}

#[derive(Debug, Clone)]
pub enum GrpcRequest<'a> {
    Unary(GrpcRequestUnary<'a>),
    Stream(GrpcRequestStream<'a>),
    Unsubscribe(GrpcRequestUnsubscribe),
}

#[derive(Debug, Clone)]
pub struct SocketRequestSend<'a> {
    pub data: &'a [u8],
}

#[derive(Debug, Clone)]
pub enum SocketRequest<'a> {
    Subscribe,
    Unsubscribe,
    Send(SocketRequestSend<'a>),
}

#[derive(Debug, Clone)]
pub enum RequestKind<'a> {
    Socket(SocketRequest<'a>),
    Grpc(GrpcRequest<'a>),
}

#[derive(Debug, Clone)]
pub struct NetRequest<'a> {
    pub transport_id: u32,
    pub id: u32,
    pub kind: RequestKind<'a>,
}

impl<'a> NetRequest<'a> {
    // return references with the same lifetime `'a`
    pub fn to_socket_request(&'a self) -> Result<&'a SocketRequest<'a>, ResultStatus> {
        match &self.kind {
            RequestKind::Socket(socket_request) => Ok(socket_request),
            _ => Err(ResultStatus::InvalidSocketRequest),
        }
    }

    pub fn to_grpc_request(&'a self) -> Result<&'a GrpcRequest<'a>, ResultStatus> {
        match &self.kind {
            RequestKind::Grpc(grpc_request) => Ok(grpc_request),
            _ => Err(ResultStatus::InvalidSocketRequest),
        }
    }
}
