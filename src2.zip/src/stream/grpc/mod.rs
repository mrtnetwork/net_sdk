use std::{
    pin::Pin,
    task::{Context, Poll},
};

use hyper_util::rt::TokioIo;
use tonic::transport::Uri;
use tower::Service;

use crate::{
    stream::ConnectStream,
    types::{
        error::ResultStatus,
        response::{NetConfig, NetMode, NetProtocol},
    },
    utils::Utils,
};
pub struct GrpcConnector<T>(std::marker::PhantomData<T>);

impl<T> Default for GrpcConnector<T> {
    fn default() -> Self {
        Self(std::marker::PhantomData)
    }
}

impl<T> Service<Uri> for GrpcConnector<T>
where
    T: ConnectStream,
{
    type Response = TokioIo<T>;
    type Error = ResultStatus;
    type Future = Pin<Box<dyn Future<Output = Result<Self::Response, Self::Error>> + Send>>;

    fn poll_ready(&mut self, _cx: &mut Context<'_>) -> Poll<Result<(), Self::Error>> {
        Poll::Ready(Ok(()))
    }

    fn call(&mut self, req: Uri) -> Self::Future {
        Box::pin(async move {
            let addr = Utils::parse_http_url(&req.to_string())?;
            let config = NetConfig {
                addr,
                mode: NetMode::Clearnet,
                protocol: NetProtocol::Grpc,
                http: None,
            };
            let stream = T::connect(&config).await?;
            Ok(TokioIo::new(stream))
        })
    }
}
