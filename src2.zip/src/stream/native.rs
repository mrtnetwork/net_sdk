pub struct StreamUtils;
use arti_client::{DataStream, StreamPrefs, TorClient, TorClientConfig};
use rustls::ClientConfig;
use rustls_platform_verifier::ConfigVerifierExt;
use std::{fmt::Debug, sync::Arc};
use tokio::{
    io::{AsyncRead, AsyncWrite},
    net::TcpStream,
    sync::OnceCell,
};
use tokio_rustls::{TlsConnector, client::TlsStream};
use tor_rtcompat::PreferredRuntime;

use crate::{
    stream::tls::TofuVerifier,
    types::{
        AddressInfo,
        error::ResultStatus,
        response::{NetConfig, NetMode, NetProtocol},
    },
    utils::Utils,
};

static TOR_CLIENT: OnceCell<TorClient<PreferredRuntime>> = OnceCell::const_new();

pub trait AsyncReadWrite: AsyncRead + AsyncWrite + Unpin + Send + Sync + Debug {}

impl<T> AsyncReadWrite for T where T: AsyncRead + AsyncWrite + Unpin + Send + Sync + Debug + 'static {}

impl StreamUtils {
    pub async fn get_tor_client() -> TorClient<PreferredRuntime> {
        TOR_CLIENT
            .get_or_init(|| async {
                let config = TorClientConfig::default();
                TorClient::create_bootstrapped(config)
                    .await
                    .expect("tor bootstrap failed")
            })
            .await
            .clone()
    }

    pub fn ensure_rustls_provider() {
        // let _ = *RUSTLS_RING_PROVIDER;
    }
    pub fn create_tls_config() -> Result<ClientConfig, ResultStatus> {
        // rustls::crypto::ring::default_provider()
        //     .install_default()
        //     .expect("failed to install rustls ring provider");
        // let mut root_store = RootCertStore::empty();
        // root_store.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
        StreamUtils::ensure_rustls_provider();
        ClientConfig::with_platform_verifier().map_err(|_| ResultStatus::TlsError)
        // let config = ClientConfig::builder()
        //     .with_root_certificates(root_store)
        //     .with_no_client_auth();
        // Ok(config)
    }
    pub fn create_no_verify_tls_config() -> Result<ClientConfig, ResultStatus> {
        StreamUtils::ensure_rustls_provider();
        Ok(ClientConfig::builder()
            .dangerous()
            .with_custom_certificate_verifier(Arc::new(TofuVerifier))
            .with_no_client_auth())
    }
    pub async fn create_tcp_stream(addr: &AddressInfo) -> Result<TcpStream, ResultStatus> {
        TcpStream::connect((addr.host.to_string(), addr.port))
            .await
            .map_err(|_| ResultStatus::NetError)
    }
    pub async fn create_tls_stream<T: AsyncReadWrite>(
        addr: &AddressInfo,
        stream: T,
        protocol: &NetProtocol,
    ) -> Result<TlsStream<T>, ResultStatus> {
        let connector = StreamUtils::create_tls_connector(protocol)?;
        let domain = Utils::get_server_name(&addr.host)?;
        let stream = connector
            .connect(domain, stream)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        println!(
            "data {:#?}",
            String::from_utf8_lossy(stream.get_ref().1.alpn_protocol().unwrap_or(&[0u8; 0]))
        );
        Ok(stream)
    }
    pub async fn create_tls_stream_no_verify<T: AsyncReadWrite>(
        addr: &AddressInfo,
        stream: T,
    ) -> Result<TlsStream<T>, ResultStatus> {
        let connector = StreamUtils::create_no_verify_tls_connector()?;
        let domain = Utils::get_server_name(&addr.host)?;
        let stream = connector
            .connect(domain, stream)
            .await
            .map_err(|_| ResultStatus::NetError)?;
        Ok(stream)
    }
    pub async fn create_tor_stream(
        addr: &AddressInfo,
    ) -> Result<arti_client::DataStream, ResultStatus> {
        println!("come createe tor");
        let client = StreamUtils::get_tor_client().await;

        let mut prefs = StreamPrefs::new();
        prefs.ipv4_only();

        let stream = client
            .connect_with_prefs((addr.host.to_string(), addr.port), &prefs)
            .await
            .map_err(|e| {
                println!("create_tor_stream error: {:#?}", e);
                ResultStatus::TorNetError
            });
        println!("tor stream done!");
        stream
    }

    pub fn create_tls_connector(protocol: &NetProtocol) -> Result<TlsConnector, ResultStatus> {
        let mut tls_config = StreamUtils::create_tls_config()?;
        match protocol {
            NetProtocol::Http | NetProtocol::Grpc => {
                tls_config.alpn_protocols = vec![b"h2".to_vec(), b"http/1.1".to_vec()];
            }
            _ => (),
        }
        Ok(TlsConnector::from(Arc::new(tls_config)))
    }
    pub fn create_no_verify_tls_connector() -> Result<TlsConnector, ResultStatus> {
        let tls_config = StreamUtils::create_no_verify_tls_config()?;
        Ok(TlsConnector::from(Arc::new(tls_config)))
    }
}

#[async_trait::async_trait]
pub trait ConnectStream: AsyncRead + AsyncWrite + Unpin + Send + Sync + Debug + 'static {
    async fn connect(config: &NetConfig) -> Result<Self, ResultStatus>
    where
        Self: Sized;
    fn alpn_protocol(&self) -> Option<&[u8]>;
}

#[async_trait::async_trait]
impl ConnectStream for TcpStream {
    async fn connect(config: &NetConfig) -> Result<Self, ResultStatus> {
        StreamUtils::create_tcp_stream(&config.addr).await
    }

    fn alpn_protocol(&self) -> Option<&[u8]> {
        return None;
    }
}

#[async_trait::async_trait]
impl ConnectStream for arti_client::DataStream {
    async fn connect(config: &NetConfig) -> Result<Self, ResultStatus> {
        StreamUtils::create_tor_stream(&config.addr).await
    }
    fn alpn_protocol(&self) -> Option<&[u8]> {
        return None;
    }
}

#[async_trait::async_trait]
impl<T> ConnectStream for TlsStream<T>
where
    T: ConnectStream + AsyncReadWrite,
{
    async fn connect(config: &NetConfig) -> Result<Self, ResultStatus> {
        let base_stream = T::connect(config).await?;
        StreamUtils::create_tls_stream(&config.addr, base_stream, &config.protocol).await
    }
    fn alpn_protocol(&self) -> Option<&[u8]> {
        return self.get_ref().1.alpn_protocol();
    }
}
pub type BoxedStream = Box<dyn ConnectStream>;
