use std::{
    collections::HashMap,
    sync::{
        Arc,
        atomic::{AtomicU32, Ordering},
    },
};

use arti_client::DataStream;
use tokio::{
    net::TcpStream,
    sync::{
        Mutex,
        broadcast::{self},
    },
};
use tokio_rustls::client::TlsStream;

use crate::{
    client::{GrpcStreamHandle, IGrpcClient, grpc::native::GrpcClient},
    transport::{Transport, native::IGrpcTransport},
    types::{
        DartCallback,
        error::ResultStatus,
        request::{GrpcRequestStream, GrpcRequestUnary, GrpcRequestUnsubscribe, NetRequest},
        response::{
            GrpcResponse, GrpcStreamIdResponse, GrpcStreamResponse, GrpcUnaryResponse, NetMode,
            NetProtocol, NetRequestConfig, ResponseKind,
        },
    },
};

pub struct GrpcTransport {
    stream: Box<dyn IGrpcClient>,
    callback: DartCallback,
    listeners: Arc<Mutex<HashMap<u32, GrpcStreamHandle>>>,
    transport_id: u32,
    next_stream_id: AtomicU32,
}
#[async_trait::async_trait]
impl Transport for GrpcTransport {
    fn create(
        config: NetRequestConfig,
        callback: DartCallback,
        transport_id: u32,
    ) -> Result<GrpcTransport, ResultStatus> {
        let config = config.to_protocol_config(NetProtocol::Grpc)?;
        let stream: Box<dyn IGrpcClient> = match config.protocol {
            NetProtocol::Grpc => match (config.addr.is_tls, &config.mode) {
                (true, NetMode::Tor) => {
                    Box::new(GrpcClient::<TlsStream<DataStream>>::default(&config)?)
                }

                (true, NetMode::Clearnet) => {
                    Box::new(GrpcClient::<TlsStream<TcpStream>>::default(&config)?)
                }

                (false, NetMode::Tor) => Box::new(GrpcClient::<DataStream>::default(&config)?),

                (false, NetMode::Clearnet) => Box::new(GrpcClient::<TcpStream>::default(&config)?),
            },
            _ => return Err(ResultStatus::InvalidProtocolParams),
        };
        Ok(Self {
            stream,
            callback,
            listeners: Arc::new(Mutex::new(HashMap::new())),
            transport_id,
            next_stream_id: AtomicU32::new(1),
        })
    }
    async fn do_request(&self, request: NetRequest) -> Result<ResponseKind, ResultStatus> {
        let socket_requset = request.to_grpc_request()?;
        let _ = match socket_requset {
            crate::types::request::GrpcRequest::Stream(e) => self.stream(e).await?,
            crate::types::request::GrpcRequest::Unary(e) => self.unary(e).await?,
            crate::types::request::GrpcRequest::Unsubscribe(e) => self.unsubscribe(e).await?,
        };
        Ok(ResponseKind::Status(ResultStatus::OK))
    }
}
#[async_trait::async_trait]
impl IGrpcTransport for GrpcTransport {
    async fn unary<'a>(&self, data: GrpcRequestUnary<'a>) -> Result<ResponseKind, ResultStatus> {
        let r = self.stream.unary(data.data, &data.method).await?;
        Ok(ResponseKind::Grpc(GrpcResponse::Unary(GrpcUnaryResponse {
            data: r,
        })))
    }

    async fn stream<'a>(&self, data: GrpcRequestStream<'a>) -> Result<ResponseKind, ResultStatus> {
        let handle = self.stream.stream(data.data, &data.method).await?;
        let id = self.next_stream_id.fetch_add(1, Ordering::Relaxed);
        let callback = self.callback.clone();
        let mut rx = handle.rx.resubscribe();
        let listeners = Arc::clone(&self.listeners);
        tokio::spawn(async move {
            loop {
                match rx.recv().await {
                    Ok(msg) => match msg {
                        Ok(data) => match data {
                            Some(b) => {
                                callback(ResponseKind::Grpc(GrpcResponse::Stream(
                                    GrpcStreamResponse { data: b, id },
                                )));
                            }
                            None => {
                                callback(ResponseKind::Status(ResultStatus::StreamComplete));
                                break;
                            }
                        },
                        Err(err) => {
                            callback(ResponseKind::Status(err));
                            break;
                        }
                    },
                    Err(broadcast::error::RecvError::Closed) => {
                        break;
                    }
                    Err(broadcast::error::RecvError::Lagged(_)) => {
                        // optional: report backpressure
                    }
                }
            }
            let mut guard = listeners.lock().await;
            guard.remove(&id);
        });
        // 3. Store it
        {
            let mut listeners = self.listeners.lock().await;
            listeners.insert(id, handle);
        }

        // 4. Return ID to caller
        Ok(ResponseKind::Grpc(GrpcResponse::StreamId(
            GrpcStreamIdResponse { id },
        )))
    }
    async fn unsubscribe(
        &self,
        data: GrpcRequestUnsubscribe,
    ) -> Result<ResponseKind, ResultStatus> {
        let mut listeners = self.listeners.lock().await;
        let handler = listeners.remove(&data.id);
        let _ = match handler {
            Some(e) => e.cancel(),
            None => (),
        };
        Ok(ResponseKind::Status(ResultStatus::OK))
    }
}
