use crate::types::{
    error::ResultStatus,
    request::{GrpcRequestStream, GrpcRequestUnary, GrpcRequestUnsubscribe, SocketRequestSend},
    response::{GrpcStreamIdResponse, GrpcUnaryResponse, ResponseKind},
};

pub mod grpc;
pub mod socket;

#[async_trait::async_trait]
pub trait ISocketTransport {
    /// Send raw bytes
    async fn send<'a>(&self, data: SocketRequestSend<'a>) -> Result<(), ResultStatus>;

    /// Subscribe to incoming messages (Dart-style stream)
    async fn subscribe(&self) -> Result<(), ResultStatus>;

    async fn unsubscribe(&self) -> Result<(), ResultStatus>;
}
#[async_trait::async_trait]
pub trait IGrpcTransport {
    /// Send raw bytes
    async fn unary<'a>(&self, data: GrpcRequestUnary<'a>) -> Result<ResponseKind, ResultStatus>;

    /// Subscribe to incoming messages (Dart-style stream)
    async fn stream<'a>(&self, data: GrpcRequestStream<'a>) -> Result<ResponseKind, ResultStatus>;

    async fn unsubscribe(&self, data: GrpcRequestUnsubscribe)
    -> Result<ResponseKind, ResultStatus>;
}
