use arti_client::DataStream;
use tokio::{
    net::TcpStream,
    sync::{
        Mutex,
        broadcast::{self, Receiver},
    },
};
use tokio_rustls::client::TlsStream;

use crate::{
    client::{IStreamClient, raw::native::RawStreamClient, websocket::native::WsStreamClient},
    transport::{Transport, native::ISocketTransport},
    types::{
        DartCallback,
        error::ResultStatus,
        request::{NetRequest, SocketRequestSend},
        response::{NetMode, NetProtocol, NetRequestConfig, ResponseKind, SocketStreamResponse},
    },
};

pub struct SocketTransport {
    stream: Box<dyn IStreamClient>,
    callback: DartCallback,
    rx: Mutex<Option<Receiver<Result<Vec<u8>, ResultStatus>>>>,
    transport_id: u32,
}
#[async_trait::async_trait]
impl Transport for SocketTransport {
    fn create(
        config: NetRequestConfig,
        callback: DartCallback,
        transport_id: u32,
    ) -> Result<Self, ResultStatus> {
        let config = config
            .to_protocol_config(NetProtocol::Socket)
            .or_else(|_| config.to_protocol_config(NetProtocol::WebSocket))?;
        let stream: Box<dyn IStreamClient> = match config.protocol {
            NetProtocol::WebSocket => match (config.addr.is_tls, &config.mode) {
                (true, NetMode::Tor) => {
                    Box::new(WsStreamClient::<TlsStream<DataStream>>::default(&config)?)
                }

                (true, NetMode::Clearnet) => {
                    Box::new(WsStreamClient::<TlsStream<TcpStream>>::default(&config)?)
                }

                (false, NetMode::Tor) => Box::new(WsStreamClient::<DataStream>::default(&config)?),

                (false, NetMode::Clearnet) => {
                    Box::new(WsStreamClient::<TcpStream>::default(&config)?)
                }
            },
            NetProtocol::Socket => match (config.addr.is_tls, &config.mode) {
                (true, NetMode::Tor) => {
                    Box::new(RawStreamClient::<TlsStream<DataStream>>::default(&config)?)
                }

                (true, NetMode::Clearnet) => {
                    Box::new(RawStreamClient::<TlsStream<TcpStream>>::default(&config)?)
                }

                (false, NetMode::Tor) => Box::new(RawStreamClient::<DataStream>::default(&config)?),

                (false, NetMode::Clearnet) => {
                    Box::new(RawStreamClient::<TcpStream>::default(&config)?)
                }
            },
            _ => return Err(ResultStatus::InvalidProtocolParams),
        };

        Ok(Self {
            stream: stream,
            callback,
            rx: Mutex::new(None),
            transport_id,
        })
    }
    async fn do_request(&self, request: NetRequest) -> Result<ResponseKind, ResultStatus> {
        let socket_requset = request.to_socket_request()?;
        let _ = match socket_requset {
            crate::types::request::SocketRequest::Subscribe => self.subscribe().await?,
            crate::types::request::SocketRequest::Unsubscribe => self.unsubscribe().await?,
            crate::types::request::SocketRequest::Send(socket_request_send) => {
                self.send(socket_request_send).await?
            }
        };
        Ok(ResponseKind::Status(ResultStatus::OK))
    }
}
#[async_trait::async_trait]
impl ISocketTransport for SocketTransport {
    async fn send<'a>(&self, data: SocketRequestSend<'a>) -> Result<(), ResultStatus> {
        self.stream.send(data.data).await
    }

    async fn subscribe(&self) -> Result<(), ResultStatus> {
        // Create a new receiver from the inner RawStreamClient
        let mut rx = self.stream.subscribe().await?;

        // Store it in self.rx
        {
            let mut guard = self.rx.lock().await;
            if guard.is_some() {
                return Ok(());
            }
            *guard = Some(rx.resubscribe()); // store a clone in the struct
        }
        let callback = self.callback.clone();
        tokio::spawn(async move {
            loop {
                match rx.recv().await {
                    Ok(msg) => match msg {
                        Ok(data) => {
                            callback(ResponseKind::Socket(SocketStreamResponse { data: data }))
                        }
                        Err(err) => {
                            callback(ResponseKind::Status(err));
                            break;
                        }
                    },
                    Err(broadcast::error::RecvError::Closed) => {
                        // let mut guard = self.rx.lock().await;
                        // *guard = None; // remove previous rx
                        // callback.on_disconnect();
                        break;
                    }
                    Err(broadcast::error::RecvError::Lagged(_)) => {}
                }
            }
        });
        Ok(())
    }

    async fn unsubscribe(&self) -> Result<(), ResultStatus> {
        self.stream.close().await;
        let mut guard = self.rx.lock().await;
        if let Some(rx) = guard.take() {
            drop(rx);
        }
        *guard = None;
        Ok(())
    }
}
