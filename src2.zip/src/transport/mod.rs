use crate::types::{
    DartCallback,
    error::ResultStatus,
    request::NetRequest,
    response::{NetRequestConfig, ResponseKind},
};

pub mod native;

#[async_trait::async_trait]
pub trait Transport {
    fn create(
        config: NetRequestConfig,
        callback: DartCallback,
        transport_id: u32,
    ) -> Result<Self, ResultStatus>
    where
        Self: Sized;
    async fn do_request(&self, request: NetRequest) -> Result<ResponseKind, ResultStatus>;
}
